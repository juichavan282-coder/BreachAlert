# BreachAlert — Ready-to-Run Project

This package is a responsive browser/PWA version of the BreachAlert project brief.

## What is included
- Responsive dashboard for phone, tablet and computer.
- Add/remove monitored email addresses.
- LocalStorage persistence.
- Breach timeline.
- Severity and leaked-data chips.
- Actionable security advice.
- Free/Family plan UI.
- Offline cache / PWA install support.
- Demo breach records so the project works immediately without API keys.
- No passwords are requested or stored.

## Run on a computer
### Simplest
Double-click `index.html` and open it in Chrome/Edge/Firefox.

### PWA/offline install
For full PWA installation and service-worker behavior, serve the folder with a local web server:
- Python: `python -m http.server 8000`
- Open `http://localhost:8000`

## Run on Android
### Easiest
Copy the `index.html`, `manifest.json` and `sw.js` files to your phone and open `index.html` in a browser/file manager.

### Better PWA mode
Upload the folder to any static web host, open the site in Chrome on Android, then use the browser menu → Add to Home screen / Install app.

## Important production note
The original project brief specifies HIBP (or another breach API), Redis caching, a queue worker, ownership-verification email, notifications and Stripe. Those pieces require a secure server-side component. Never put an HIBP API key, email-service secret, Stripe secret key, or other private credential in browser JavaScript.

This package therefore uses demo data by default so it is genuinely runnable without credentials. A production backend can replace `breachesFor(email)` with a secure API endpoint.

## Suggested production architecture
React/PWA frontend → FastAPI/Express backend → HIBP → Redis cache/queue → email/SMS provider.
User email ownership should be verified before monitoring.

## Source basis
The project brief describes:
- HIBP/similar breach API integration.
- Redis caching and queueing for rate limits.
- Ad-hoc and nightly scans.
- Multiple monitored emails and ownership verification.
- Breach timeline and leaked data types.
- Email alerts and actionable advice.
- Free and Family tiers.
- Python or Node.js, React.js, Express/Django/FastAPI, SQL and Redis.
